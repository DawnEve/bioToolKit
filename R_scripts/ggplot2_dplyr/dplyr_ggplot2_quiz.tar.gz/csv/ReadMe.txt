/**
目的：学习 R 语言 dplyr 与 ggplot2 数据流作图的方法。

数据见2个csv文件，其中的 codebook 是解释说明。
问题见图片。
参考答案见 Rmd和html文件。
2021/11/9

版本:
R 4.1.1
dplyr 1.0.7
ggplot2 3.3.5



###########
Q2: 
原句
a bar chart of average pct of vote that AfD received in 2021 by the party that won the seat in 2017.

补充一个祈使句动词
Draw a bar chart of average pct of vote that AfD received in 2021 by the party that won the seat in 2017.

seat 是 constituency 吗？
constituency [kənˈstɪtʃuənsi] n. 选区，选区的选民；支持者，顾客
seat [siːt] n. 座位；（椅子等的）座部；（机器的）基座；（议会、委员会、法庭等的）席位，职位；<英> 议会议员选区；
应该是一个意思。


断句
a bar chart of average pct of vote that
	AfD received in 2021 by the party that
	won the seat in 2017.
	
加括号，简化
bar chart of mean(pct of vote) that
	(AfD received in 2021) by [the party] that
	(won the seat in 2017).

- 第一个that, 后面修饰vote的，是AfD在2021收到的vote;
- by 是修饰谁的？by是pct的分子分母分割线吗? 既像又不像
- the party 是谁？ 是AfD 吗？既像又不像
- 第二个that, 修饰 the party 的，2017赢得该席位的party


(0) 一个柱状图，显示在2017年赢得席位的政党在2021年获得的选票的平均百分比

a bar chart of 
  average pct of vote that
  	(AfD received in 2021) 
  	by 
  	(the party that won the seat in 2017).
	
理解1: by 是分子分母分界线, the party 是泛指2017赢了的party。
就是 AfD_2021 / (winner of 2017)_2021，再求平均值
*/